//ORIGINAL

import SwiftUI
import PlaygroundSupport

public var textcont = 0

struct Scene1: View {
    
    @State var disabled = 0 //disabilita il bottone "Next"
    @State var text1: String = "" //prima riga del testo
    @State var text2: String = "" //seconda riga del testo
    @State var text3: String = "" //terza riga del testo
    
    var body: some View {
        ZStack{
            VStack{
                Image(uiImage: UIImage(named: "Paris.jpg")!)
                    .resizable()
                    .aspectRatio(1.5, contentMode: .fit)
                    .frame(width: 650, height: 400)
                
                Rectangle()
                    .frame(width: 650, height: 300)
                    .position(x: 325, y: 135)
                
            }
            
            //Uso più "text", uno per ogni riga di testo, per evitare il lag del'animazione
            
            VStack{
                Text(text1).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 450)
                    .foregroundColor(Color.white)
                Text(text2).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 250)
                    .foregroundColor(Color.white)
                Text(text3).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 50)
                    .foregroundColor(Color.white)
            }
            
            //Bottone per avanzare con il testo e con le varie scene
            
            Button{
                if (disabled == 0)
                {
                    disabled = 1 //disabilito il bottone
                    textcont = textcont + 1
                    if (textcont == 1)
                    {
                        
                        text1 = ""
                        "It was an ordinary day in France when suddenly the French streets ".enumerated().forEach { index, character in
                            DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                
                                text1 += String(character)
                                
                                
                                
                            }
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 3){
                            text2 = ""
                            "were crossed by an unexpected guest, the pope!".enumerated().forEach { index, character in
                                DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                    
                                    text2 += String(character)
                                    
                                }
                                
                            }
                            
                        }
                        
                        //Attendo che il testo venga completamente scritto prima di riabilitare il bottone
                        DispatchQueue.main.asyncAfter(deadline: .now() + 5.5)
                        {
                            disabled = 0
                        }
                    }
                    else
                    {
                        if (textcont == 2)
                        {
                            text1 = ""
                            "But what was the pope doing in France? A trip? likely, ".enumerated().forEach { index, character in
                                DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                    text1 += String(character)
                                }
                            }
                            
                            text2 = ""
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.9)
                            {
                                "No one could tell yet but one thing was certain, ".enumerated().forEach { index, character in
                                    DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                        text2 += String(character)
                                    }
                                }
                            }
                            
                            text3 = ""
                            
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 5.5)
                            {
                                "at the end of the journey no one would forget.".enumerated().forEach { index, character in
                                    DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                        text3 += String(character)
                                    }
                                }
                                
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 8.0)
                            {
                                disabled = 0
                            }
                            
                        }
                        else
                        {
                            PlaygroundPage.current.setLiveView(Scene2())
                        }
                        
                    }
                    
                }
                
            }
        label: {Text("Next")}
        .frame(width: 75, height: 30)
        .foregroundColor(Color.white)
        .border(Color.white)
        .position(x: 550, y: 625)
            
            Image(uiImage: UIImage(named: "Pope.jpg")!)
                .resizable()
                .scaledToFit()
                .frame(width: 150, height: 150)
                .position(x: 215, y: 260)
            
        }
        
        
    }
    
}



struct Scene2: View {
    
    @State var disabled = 0
    @State var text1: String = ""
    @State var text2: String = ""
    @State var text3: String = ""
    
    var body: some View {
        ZStack{
            VStack{
                Image(uiImage: UIImage(named: "Zoo.jpg")!)
                    .resizable()
                    .aspectRatio(1.5, contentMode: .fit)
                    .frame(width: 650, height: 400)
                
                Rectangle()
                    .frame(width: 650, height: 300)
                    .position(x: 325, y: 135)
                
                
            }
            
            VStack{
                Text(text1).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 450)
                    .foregroundColor(Color.white)
                Text(text2).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 250)
                    .foregroundColor(Color.white)
                Text(text3).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 50)
                    .foregroundColor(Color.white)
            }
            
            Button{
                if (disabled == 0)
                {
                    disabled = 1
                    textcont = textcont + 1
                    if (textcont == 4)
                    {
                        text1 = ""
                        "The first thing the pope did was unexpected, ".enumerated().forEach { index, character in
                            DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                text1 += String(character)
                            }
                        }
                        
                        text2 = ""
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.2)
                        {
                            "he didn't visit the Eiffel tower,".enumerated().forEach { index, character in
                                DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                    text2 += String(character)
                                }
                            }
                        }
                        
                        text3 = ""
                        DispatchQueue.main.asyncAfter(deadline: .now() + 3.8)
                        {
                            "he didn't visit the city nor museums, he went to the zoo !".enumerated().forEach { index, character in
                                DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                    text3 += String(character)
                                }
                            }
                        }
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 7.5)
                        {
                            disabled = 0
                        }
                        
                    }
                    else
                    {
                        PlaygroundPage.current.setLiveView(Scene3())
                    }
                }
                
            }
        label: {Text("Next")}
        .frame(width: 75, height: 30)
        .foregroundColor(Color.white)
        .border(Color.white)
        .position(x: 550, y: 625)
            
            
        }
    }
    
}

struct Scene3: View {
    
    @State var disabled = 0
    @State var text1: String = ""
    @State var text2: String = ""
    @State var text3: String = ""
    
    
    var body: some View {
        ZStack{
            VStack{
                Image(uiImage: UIImage(named: "Zoo2.jpg")!)
                    .resizable()
                    .aspectRatio(1.5, contentMode: .fit)
                    .frame(width: 650, height: 400)
                
                Rectangle()
                    .frame(width: 650, height: 300)
                    .position(x: 325, y: 135)
                
                
            }
            
            VStack{
                Text(text1).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 450)
                    .foregroundColor(Color.white)
                Text(text2).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 250)
                    .foregroundColor(Color.white)
                Text(text3).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 50)
                    .foregroundColor(Color.white)
            }
            Button{
                if (disabled == 0)
                {
                    disabled = 1
                    textcont = textcont + 1
                    if (textcont == 6)
                    {
                        text1 = ""
                        "What was a pope doing in a French zoo? who can tell?".enumerated().forEach { index, character in
                            DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                text1 += String(character)
                            }
                        }
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0)
                        {
                            disabled = 0
                        }
                    }
                    else
                    {
                        if (textcont == 7)
                        {
                            text1 = ""
                            "He probably just wanted to enjoy the beauty of the animals,".enumerated().forEach { index, character in
                                DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                    text1 += String(character)
                                }
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0)
                            {
                                text2 = ""
                                "but after touring most of the zoo, he finally found what he needed,".enumerated().forEach { index, character in
                                    DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                        text2 += String(character)
                                    }
                                }
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 6.7)
                            {
                                disabled = 0
                            }
                            
                        }
                        else
                        {
                            if (textcont == 8)
                            {
                                text1 = ""
                                "what the France would remember for centuries to come,".enumerated().forEach { index, character in
                                    DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                        text1 += String(character)
                                    }
                                }
                                
                                text2 = ""
                                
                                DispatchQueue.main.asyncAfter(deadline: .now() + 2.8)
                                {
                                    "the best partner in crime a pope has ever seen, a panda.".enumerated().forEach { index, character in
                                        DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                            text2 += String(character)
                                        }
                                    }
                                }
                                
                                DispatchQueue.main.asyncAfter(deadline: .now() + 6.0)
                                {
                                    disabled = 0
                                }
                            }
                            else
                            {
                                PlaygroundPage.current.setLiveView(Scene4())
                            }
                        }
                    }
                }
                
            }
        label: {Text("Next")}
        .frame(width: 75, height: 30)
        .foregroundColor(Color.white)
        .border(Color.white)
        .position(x: 550, y: 625)
            HStack{
                
                Image(uiImage: UIImage(named: "Panda1.jpg")!)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 90, height: 90)
                    .position(x: 355, y: 300)
                
                Image(uiImage: UIImage(named: "Pope.jpg")!)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 90, height: 90)
                    .position(x: 235, y: 210)
                
            }
            
        }
    }
    
}

struct Scene4: View {
    
    @State var disabled = 0
    @State var text1: String = ""
    @State var text2: String = ""
    @State var text3: String = ""
    
    var body: some View {
        ZStack{
            VStack{
                Image(uiImage: UIImage(named: "Louvre1.jpg")!)
                    .resizable()
                    .aspectRatio(1.5, contentMode: .fit)
                    .frame(width: 650, height: 400)
                
                Rectangle()
                    .frame(width: 650, height: 300)
                    .position(x: 325, y: 135)
            }
            
            VStack{
                Text(text1).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 450)
                    .foregroundColor(Color.white)
                Text(text2).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 250)
                    .foregroundColor(Color.white)
                Text(text3).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 50)
                    .foregroundColor(Color.white)
            }
            Button{
                if (disabled == 0)
                {
                    disabled = 1
                    textcont = textcont + 1
                    if (textcont == 10)
                    {
                        text1 = ""
                        "You may be wondering what a pope and a panda ".enumerated().forEach { index, character in
                            DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                text1 += String(character)
                            }
                        }
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.2)
                        {
                            text2 = ""
                            "are doing in the most romantic city in the world,".enumerated().forEach { index, character in
                                DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                    text2 += String(character)
                                }
                            }
                        }
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 5)
                        {
                            disabled = 0
                        }
                        
                    }
                    else
                    {
                        if (textcont == 11)
                        {
                            
                            text1 = ""
                            text2 = ""
                            "a date? were they intent on stuffing themselves with croissants?".enumerated().forEach { index, character in
                                DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                    text1 += String(character)
                                }
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 4)
                            {
                                disabled = 0
                            }
                        }
                        else
                        {
                            if (textcont == 12)
                            {
                                text1 = ""
                                "The truth is that they have been spotted, at night,".enumerated().forEach { index, character in
                                    DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                        text1 += String(character)
                                    }
                                }
                                
                                text2 = ""
                                
                                DispatchQueue.main.asyncAfter(deadline: .now() + 2.2)
                                {
                                    "outside one of the most important museums in France, the Louvre!".enumerated().forEach { index, character in
                                        DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                            text2 += String(character)
                                        }
                                    }
                                }
                                
                                DispatchQueue.main.asyncAfter(deadline: .now() + 6)
                                {
                                    disabled = 0
                                }
                            }
                            else
                            {
                                PlaygroundPage.current.setLiveView(Scene5())
                            }
                        }
                    }
                    
                }
            }
        label: {Text("Next")}
        .frame(width: 75, height: 30)
        .foregroundColor(Color.white)
        .border(Color.white)
        .position(x: 550, y: 625)
            HStack{
                
                Image(uiImage: UIImage(named: "Panda2inverted.jpg")!)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 125, height: 125)
                    .position(x: 110, y: 335)
                Image(uiImage: UIImage(named: "Popeinvert.jpg")!)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 115, height: 115)
                    .position(x: -110, y: 315)
                
                
            }
            
        }
    }
    
}

struct Scene5: View {
    
    @State var disabled = 0
    @State var text1: String = ""
    @State var text2: String = ""
    @State var text3: String = ""
    
    var body: some View {
        ZStack{
            VStack{
                Image(uiImage: UIImage(named: "Louvre2.jpg")!)
                    .resizable()
                    .aspectRatio(1.5, contentMode: .fit)
                    .frame(width: 650, height: 400)
                
                
                Rectangle()
                    .frame(width: 650, height: 300)
                    .position(x: 325, y: 135)
                
            }
            
            VStack{
                Text(text1).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 450)
                    .foregroundColor(Color.white)
                Text(text2).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 250)
                    .foregroundColor(Color.white)
                Text(text3).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 50)
                    .foregroundColor(Color.white)
            }
            
            Button{
                if (disabled == 0)
                {
                    disabled = 1
                    textcont = textcont + 1
                    if (textcont == 14)
                    {
                        text1 = ""
                        "Although it was night, and the louvre was closed".enumerated().forEach { index, character in
                            DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                text1 += String(character)
                            }
                        }
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 3)
                        {
                            disabled = 0
                        }
                    }
                    else
                    {
                        if (textcont == 15)
                        {
                            text1 = ""
                            "the pope and the panda walked inside the museum".enumerated().forEach { index, character in
                                DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                    text1 += String(character)
                                }
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5)
                            {
                                text2 = ""
                                "in a rather suspicious way.".enumerated().forEach { index, character in
                                    DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                        text2 += String(character)
                                    }
                                }
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 4)
                            {
                                disabled = 0
                            }
                        }
                        else
                        {
                            PlaygroundPage.current.setLiveView(Scene6())
                            
                        }
                    }
                    
                }
                
            }
        label: {Text("Next")}
        .frame(width: 75, height: 30)
        .foregroundColor(Color.white)
        .border(Color.white)
        .position(x: 550, y: 625)
            HStack{
                
                Image(uiImage: UIImage(named: "Panda2inverted.jpg")!)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 125, height: 125)
                    .position(x: 110, y: 325)
                
                Image(uiImage: UIImage(named: "Popeinvert.jpg")!)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 115, height: 115)
                    .position(x: -110, y: 305)
                
                
            }
            
        }
    }
    
}

struct Scene6: View {
    
    @State var bite = 0 //Indica se il morso è avvenuto o no
    @State var Ruba = 0 //Indica se la Gioconda è stata rubata
    @State var disabled = 0
    @State var text1: String = ""
    @State var text2: String = ""
    @State var text3: String = ""
    
    var body: some View {
        ZStack{
            
            VStack{
                if (bite == 0 || bite == 2)
                {
                    Image(uiImage: UIImage(named: "Stand.jpg")!)
                        .resizable()
                        .aspectRatio(1.5, contentMode: .fit)
                        .frame(width: 650, height: 400)
                }
                else
                {
                    
                    Image(uiImage: UIImage(named: "Morso.jpg")!)
                        .resizable()
                    
                        .frame(width: 650, height: 400)
                }
                Rectangle()
                    .frame(width: 650, height: 300)
                    .position(x: 325, y: 135)
                
            }
            VStack{
                Text(text1).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 450)
                    .foregroundColor(Color.white)
                Text(text2).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 250)
                    .foregroundColor(Color.white)
                Text(text3).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 50)
                    .foregroundColor(Color.white)
            }
            Button{
                if (disabled == 0)
                {
                    disabled = 1
                    textcont = textcont + 1
                    if (textcont == 17)
                    {
                        text1 = ""
                        "They arrived at the room that contained".enumerated().forEach { index, character in
                            DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                text1 += String(character)
                            }
                        }
                        
                        text2 = ""
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0)
                        {
                            "one of the best masterpieces of art, The Mona Lisa.".enumerated().forEach { index, character in
                                DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                    text2 += String(character)
                                }
                            }
                        }
                        
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 4.7)
                        {
                            disabled = 0
                        }
                    }
                    else
                    {
                        if (textcont == 18)
                        {
                            text1 = ""
                            text2 = ""
                            "The intention was now clear, the pope wanted to steal the Mona Lisa !".enumerated().forEach { index, character in
                                DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                    text1 += String(character)
                                }
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 3.8)
                            {
                                disabled = 0
                            }
                            
                        }
                        else
                        {
                            if (textcont == 19)
                            {
                                text1 = ""
                                "But there was someone waiting for him who would try to interfere him:".enumerated().forEach { index, character in
                                    DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                        text1 += String(character)
                                    }
                                }
                                
                                text2 = ""
                                
                                DispatchQueue.main.asyncAfter(deadline: .now() + 3.6)
                                {
                                    "Leonardo Da ''Vinchi''!".enumerated().forEach { index, character in
                                        DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                            text2 += String(character)
                                        }
                                    }
                                }
                                
                                
                                DispatchQueue.main.asyncAfter(deadline: .now() + 5.3)
                                {
                                    disabled = 0
                                }
                                
                            }
                            else
                            {
                                if (textcont == 20)
                                {
                                    text1 = ""
                                    "Apparently the author of the Mona Lisa was determined to defend".enumerated().forEach { index, character in
                                        DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                            text1 += String(character)
                                        }
                                    }
                                    
                                    text2 = ""
                                    
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 3.2)
                                    {
                                        "his painting even at the cost of fighting the pope!".enumerated().forEach { index, character in
                                            DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                                text2 += String(character)
                                            }
                                        }
                                    }
                                    
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 6.3)
                                    {
                                        disabled = 0
                                    }
                                    
                                }
                                else
                                {
                                    if (textcont == 21)
                                    {
                                        bite = 1
                                        text1 = ""
                                        "At this point the panda intervenes and with a bite".enumerated().forEach { index, character in
                                            DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                                text1 += String(character)
                                            }
                                        }
                                        
                                        text2 = ""
                                        
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.7)
                                        {
                                            "puts Da ''Vinchi'' out of the game.".enumerated().forEach { index, character in
                                                DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                                    text2 += String(character)
                                                }
                                            }
                                            
                                        }
                                        
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 5.0)
                                        {
                                            disabled = 0
                                        }
                                        
                                        
                                    }
                                    else
                                    {
                                        if (textcont == 22)
                                        {
                                            bite = 2
                                            text2 = ""
                                            text1 = ""
                                            "Once he had put the enemy out of business, ".enumerated().forEach { index, character in
                                                DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                                    text1 += String(character)
                                                }
                                            }
                                            
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.6)
                                            {
                                                disabled = 0
                                            }
                                            
                                        }
                                        else
                                        {
                                            if (textcont == 23)
                                            {
                                                Ruba = 1
                                                text1 = ""
                                                "the pope finally accomplished his goal.".enumerated().forEach { index, character in
                                                    DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                                        text1 += String(character)
                                                    }
                                                }
                                                
                                                DispatchQueue.main.asyncAfter(deadline: .now() + 2.4)
                                                {
                                                    disabled = 0
                                                }
                                                
                                            }
                                            else
                                            {
                                                PlaygroundPage.current.setLiveView(Scene7())
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        
                    }
                }
                
            }
        label: {Text("Next")}
        .frame(width: 75, height: 30)
        .foregroundColor(Color.white)
        .border(Color.white)
        .position(x: 550, y: 625)
            
            if (bite == 0 || bite == 2)
            {
                if (Ruba == 0)
                {
                    Image(uiImage: UIImage(named: "Monalisa.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 125, height: 125)
                        .position(x: 325, y: 170)
                }
                else
                {
                    Rectangle()
                        .frame(width: 85, height: 125)
                        .position(x: 323, y: 170)
                }
                
                HStack{
                    
                    if (bite == 2)
                    {
                        Image(uiImage: UIImage(named: "Davinchi.jpg")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 150, height: 150)
                            .rotationEffect(.degrees(90))
                            .position(x: 130, y: 330)
                        
                        Image(uiImage: UIImage(named: "Panda2.jpg")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 150, height: 150)
                            .position(x: 80, y: 315)
                        
                        if (Ruba == 0)
                        {
                            Image(uiImage: UIImage(named: "Pope.jpg")!)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 150, height: 150)
                                .position(x: 100, y: 285)
                        }
                        else
                        {
                            Image(uiImage: UIImage(named: "papalisa.jpg")!)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 150, height: 150)
                                .position(x: 100, y: 285)
                        }
                        
                    }
                    else
                    {
                        Image(uiImage: UIImage(named: "Davinchi.jpg")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 150, height: 150)
                            .position(x: 130, y: 280)
                        
                        if (Ruba == 0)
                        {
                            Image(uiImage: UIImage(named: "Pope.jpg")!)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 150, height: 150)
                                .position(x: 210, y: 280)
                        }
                        else
                        {
                            Image(uiImage: UIImage(named: "papalisa.jpg")!)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 150, height: 150)
                                .position(x: 210, y: 280)
                        }
                        
                        Image(uiImage: UIImage(named: "Panda2.jpg")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 150, height: 150)
                            .position(x: 120, y: 315)
                        
                        
                    }
                    
                    
                    
                    
                }
            }
        }
        
    }
    
}

struct Scene7: View {
    
    @State var disabled = 0
    @State var text1: String = ""
    @State var text2: String = ""
    @State var text3: String = ""
    
    var body: some View {
        ZStack{
            VStack{
                Image(uiImage: UIImage(named: "Piazza.jpg")!)
                    .resizable()
                    .aspectRatio(1.5, contentMode: .fit)
                    .frame(width: 650, height: 400)
                
                Rectangle()
                    .frame(width: 650, height: 300)
                    .position(x: 325, y: 135)
                
            }
            
            VStack{
                Text(text1).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 450)
                    .foregroundColor(Color.white)
                Text(text2).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 250)
                    .foregroundColor(Color.white)
                Text(text3).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 50)
                    .foregroundColor(Color.white)
            }
            Button{
                if (disabled == 0)
                {
                    disabled = 1
                    textcont = textcont + 1
                    if (textcont == 25)
                    {
                        text1 = ""
                        "Finally his adventure in France was over and".enumerated().forEach { index, character in
                            DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                text1 += String(character)
                            }
                        }
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.2)
                        {
                            text2 = ""
                            "he could finally return home,".enumerated().forEach { index, character in
                                DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                    text2 += String(character)
                                }
                            }
                        }
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 4)
                        {
                            disabled = 0
                        }
                        
                    }
                    else
                    {
                        if (textcont == 26)
                        {
                            text1 = ""
                            "the Vatican City, taking with him his partner in crime,".enumerated().forEach { index, character in
                                DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                    text1 += String(character)
                                }
                            }
                            
                            text2 = ""
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.8)
                            {
                                "the panda.".enumerated().forEach { index, character in
                                    DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                        text2 += String(character)
                                    }
                                }
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 3.7)
                            {
                                disabled = 0
                            }
                            
                        }
                        else
                        {
                            PlaygroundPage.current.setLiveView(Scene8())
                        }
                    }
                    
                }
            }
        label: {Text("Next")}
        .frame(width: 75, height: 30)
        .foregroundColor(Color.white)
        .border(Color.white)
        .position(x: 550, y: 625)
            
            HStack{
                
                Image(uiImage: UIImage(named: "papalisa.jpg")!)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 115, height: 115)
                    .position(x: 400, y: 320)
                
                Image(uiImage: UIImage(named: "Panda2.jpg")!)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 125, height: 125)
                    .position(x: 180, y: 335)
            }
            
        }
    }
    
}

struct Scene8: View {
    
    
    @State var disabled = 0
    @State var text1: String = ""
    @State var text2: String = ""
    @State var text3: String = ""
    @State var vescovo = 0 //Indica se il panda è stato fatto Vescovo
    
    var body: some View {
        ZStack{
            VStack{
                Image(uiImage: UIImage(named: "Chiesa.jpg")!)
                    .resizable()
                    .aspectRatio(1.5, contentMode: .fit)
                    .frame(width: 650, height: 400)
                
                Rectangle()
                    .frame(width: 650, height: 300)
                    .position(x: 325, y: 135)
                
            }
            
            VStack{
                Text(text1).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 450)
                    .foregroundColor(Color.white)
                Text(text2).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 250)
                    .foregroundColor(Color.white)
                Text(text3).animation(.spring())
                    .frame(width: 550, height: 100)
                    .position(x: 325, y: 50)
                    .foregroundColor(Color.white)
            }
            Button{
                if (disabled == 0)
                {
                    disabled = 1
                    textcont = textcont + 1
                    if (textcont == 28)
                    {
                        text1 = ""
                        "Just bringing the panda with him didn't seem enough,".enumerated().forEach { index, character in
                            DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                text1 += String(character)
                            }
                        }
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.7)
                        {
                            text2 = ""
                            "he wanted to reward him for his loyalty".enumerated().forEach { index, character in
                                DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                    text2 += String(character)
                                }
                            }
                        }
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 4.8)
                        {
                            disabled = 0
                        }
                    }
                    else
                    {
                        if (textcont == 29)
                        {
                            text1 = ""
                            "and then he remembered when Caligula elected a horse as a senator".enumerated().forEach { index, character in
                                DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                    text1 += String(character)
                                }
                            }
                            
                            text2 = ""
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 3.2)
                            {
                                "and what better way to replicate the same thing?".enumerated().forEach { index, character in
                                    DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                        text2 += String(character)
                                    }
                                }                        }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 6.0)
                            {
                                disabled = 0
                            }
                        }
                        else
                        {
                            if (textcont == 30)
                            {
                                vescovo = 1
                                text1 = ""
                                "And here is the story of how a panda".enumerated().forEach { index, character in
                                    DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                        text1 += String(character)
                                    }
                                }
                                
                                text2 = ""
                                
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.8)
                                {
                                    "from a French zoo became a bishop!".enumerated().forEach { index, character in
                                        DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                            text2 += String(character)
                                        }
                                    }
                                }
                                
                                DispatchQueue.main.asyncAfter(deadline: .now() + 4)
                                {
                                    disabled = 0
                                }
                            }
                            else
                            {
                                PlaygroundPage.current.setLiveView(Crediti())                            }
                        }
                    }
                    
                }
                
            }
        label: {Text("Next")}
        .frame(width: 75, height: 30)
        .foregroundColor(Color.white)
        .border(Color.white)
        .position(x: 550, y: 625)
            
            Image(uiImage: UIImage(named: "Monalisa.jpg")!)
                .resizable()
                .scaledToFit()
                .frame(width: 95, height: 95)
                .position(x: 188, y: 135)
            
            
            HStack{
                
                if (vescovo == 0)
                {
                    Image(uiImage: UIImage(named: "Panda2inverted.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 150, height: 150)
                        .position(x: 180, y: 265)
                }
                else
                {
                    Image(uiImage: UIImage(named: "pandavescovo.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 230, height: 230)
                        .position(x: 173, y: 240)
                }
                
                
                Image(uiImage: UIImage(named: "Pope.jpg")!)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 150, height: 150)
                    .position(x: 150, y: 235)
                
            }
            
        }
    }
    
}

struct Crediti: View {
    
    @State var theend = 0 //Variabile utilizzata per nascondere il bottone "Next"
    @State var End: String = "" //Stringa "THE END"
    @State var Coffee: String = "" //Stringa nome del team
    @State var text1: String = "" //primo mebro del team
    @State var text2: String = "" //secondo membro del team
    @State var text3: String = "" //terzo membro del team
    @State var text4: String = "" //quarto membro del team
    
    var body: some View {
        ZStack{
            VStack{
                Rectangle()
                    .frame(width: 650, height: 400)
                
                Rectangle()
                    .frame(width: 650, height: 300)
                    .position(x: 325, y: 135)
                
            }
            VStack{
                Text(End).animation(.spring())
                    .font(.system(size: 65))
                    .frame(width: 450, height: 100)
                    .position(x: 325, y: 150)
                    .foregroundColor(Color.white)
                    .font(.system(size: 22))
                Text(Coffee).animation(.spring())
                    .font(.system(size: 25))
                    .frame(width: 450, height: 100)
                    .position(x: 325, y: 150)
                    .foregroundColor(Color.white)
                Text(text1).animation(.spring())
                    .font(.system(size: 15))
                    .frame(width: 200, height: 100)
                    .position(x: 325, y: 120)
                    .foregroundColor(Color.white)
                Text(text2).animation(.spring())
                    .font(.system(size: 15))
                    .frame(width: 200, height: 100)
                    .position(x: 325, y: 50)
                    .foregroundColor(Color.white)
                Text(text3).animation(.spring())
                    .font(.system(size: 15))
                    .frame(width: 200, height: 100)
                    .position(x: 325, y: -20)
                    .foregroundColor(Color.white)
                Text(text4).animation(.spring())
                    .font(.system(size: 15))
                    .frame(width: 200, height: 100)
                    .position(x: 325, y: -90)
                    .foregroundColor(Color.white)
            }
            if (theend == 0)
            {
                Button{
                    
                    theend = 1
                    End = "THE END"
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        Coffee = ""
                        "Popepanda in Action by Coffee Guys:".enumerated().forEach { index, character in
                            DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                Coffee += String(character)
                            }
                        }
                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                        text1 = ""
                        "Antonio Pisani".enumerated().forEach { index, character in
                            DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                text1 += String(character)
                            }
                        }
                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.7){
                        text2 = ""
                        "Claudio Silvestri".enumerated().forEach { index, character in
                            DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                text2 += String(character)
                            }
                        }
                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3.6){
                        text3 = ""
                        "Giovanni Di Falco".enumerated().forEach { index, character in
                            DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                text3 += String(character)
                            }
                        }
                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 4.2){
                        text4 = ""
                        "Raffaele Colantonio".enumerated().forEach { index, character in
                            DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.05) {
                                text4 += String(character)
                            }
                        }
                    }
                    
                    
                    
                    
                }
            label: {Text("Next")}
            .frame(width: 75, height: 30)
            .foregroundColor(Color.white)
            .border(Color.white)
            .position(x: 550, y: 625)
            }
        }
    }
    
}

PlaygroundPage.current.setLiveView(Scene1())

